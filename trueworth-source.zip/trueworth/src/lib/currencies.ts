export type Currency = { code: string; name: string; flag: string };

/** Frankfurter v2 returns currency records, not an object keyed by code. */
export function normalizeCurrencies(raw: unknown, fallback: Array<[string, string, string]>): Currency[] {
  if (!Array.isArray(raw)) throw new Error("Invalid currency response");
  const known = new Map(fallback.map(([code, name, flag]) => [code, { name, flag }]));
  const currencies = new Map<string, Currency>();
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const { iso_code, name } = item as Record<string, unknown>;
    if (typeof iso_code !== "string" || !/^[A-Z]{3}$/.test(iso_code)) continue;
    currencies.set(iso_code, {
      code: iso_code,
      name: typeof name === "string" && name.trim() ? name : (known.get(iso_code)?.name ?? iso_code),
      flag: known.get(iso_code)?.flag ?? "💱",
    });
  }
  if (!currencies.size) throw new Error("No valid currencies returned");
  return [...currencies.values()].sort((a, b) =>
    a.code === "USD" ? -1 : b.code === "USD" ? 1 : a.code.localeCompare(b.code),
  );
}