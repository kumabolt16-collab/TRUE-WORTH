import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { normalizeCurrencies } from "@/lib/currencies";

const DEX = "https://api.dexscreener.com";
const FX = "https://api.frankfurter.dev/v2";
const GECKO = "https://api.geckoterminal.com/api/v2";

const DAI_USER_DAILY_LIMIT = 3;
const DAI_GLOBAL_DAILY_LIMIT = 30;

export const CURRENCY_FALLBACK: Array<[string, string, string]> = [
  ["USD", "US Dollar", "🇺🇸"], ["NGN", "Nigerian Naira", "🇳🇬"], ["GHS", "Ghanaian Cedi", "🇬🇭"],
  ["KES", "Kenyan Shilling", "🇰🇪"], ["ZAR", "South African Rand", "🇿🇦"], ["UGX", "Ugandan Shilling", "🇺🇬"],
  ["TZS", "Tanzanian Shilling", "🇹🇿"], ["RWF", "Rwandan Franc", "🇷🇼"], ["ETB", "Ethiopian Birr", "🇪🇹"],
  ["EGP", "Egyptian Pound", "🇪🇬"], ["MAD", "Moroccan Dirham", "🇲🇦"], ["XOF", "West African CFA Franc", "🌍"],
  ["XAF", "Central African CFA Franc", "🌍"], ["EUR", "Euro", "🇪🇺"], ["GBP", "British Pound", "🇬🇧"],
  ["CHF", "Swiss Franc", "🇨🇭"], ["NOK", "Norwegian Krone", "🇳🇴"], ["SEK", "Swedish Krona", "🇸🇪"],
  ["DKK", "Danish Krone", "🇩🇰"], ["PLN", "Polish Zloty", "🇵🇱"], ["CZK", "Czech Koruna", "🇨🇿"],
  ["RON", "Romanian Leu", "🇷🇴"], ["TRY", "Turkish Lira", "🇹🇷"], ["UAH", "Ukrainian Hryvnia", "🇺🇦"],
  ["INR", "Indian Rupee", "🇮🇳"], ["CNY", "Chinese Yuan", "🇨🇳"], ["JPY", "Japanese Yen", "🇯🇵"],
  ["KRW", "South Korean Won", "🇰🇷"], ["IDR", "Indonesian Rupiah", "🇮🇩"], ["PHP", "Philippine Peso", "🇵🇭"],
  ["MYR", "Malaysian Ringgit", "🇲🇾"], ["SGD", "Singapore Dollar", "🇸🇬"], ["THB", "Thai Baht", "🇹🇭"],
  ["VND", "Vietnamese Dong", "🇻🇳"], ["PKR", "Pakistani Rupee", "🇵🇰"], ["BDT", "Bangladeshi Taka", "🇧🇩"],
  ["AED", "UAE Dirham", "🇦🇪"], ["SAR", "Saudi Riyal", "🇸🇦"], ["QAR", "Qatari Riyal", "🇶🇦"],
  ["KWD", "Kuwaiti Dinar", "🇰🇼"], ["BHD", "Bahraini Dinar", "🇧🇭"], ["OMR", "Omani Rial", "🇴🇲"],
  ["ILS", "Israeli New Shekel", "🇮🇱"], ["JOD", "Jordanian Dinar", "🇯🇴"], ["CAD", "Canadian Dollar", "🇨🇦"],
  ["AUD", "Australian Dollar", "🇦🇺"], ["NZD", "New Zealand Dollar", "🇳🇿"], ["BRL", "Brazilian Real", "🇧🇷"],
  ["MXN", "Mexican Peso", "🇲🇽"], ["ARS", "Argentine Peso", "🇦🇷"], ["CLP", "Chilean Peso", "🇨🇱"],
  ["COP", "Colombian Peso", "🇨🇴"], ["PEN", "Peruvian Sol", "🇵🇪"], ["KZT", "Kazakhstani Tenge", "🇰🇿"],
  ["ZMW", "Zambian Kwacha", "🇿🇲"], ["BWP", "Botswana Pula", "🇧🇼"], ["MZN", "Mozambican Metical", "🇲🇿"],
  ["AOA", "Angolan Kwanza", "🇦🇴"], ["MUR", "Mauritian Rupee", "🇲🇺"], ["SCR", "Seychellois Rupee", "🇸🇨"],
  ["NAD", "Namibian Dollar", "🇳🇦"], ["RUB", "Russian Ruble", "🇷🇺"],
];

const GECKO_NETWORKS: Record<string, string> = {
  ethereum: "eth", eth: "eth", bsc: "bsc", polygon: "polygon_pos", polygon_pos: "polygon_pos",
  arbitrum: "arbitrum", optimism: "optimism", base: "base", avalanche: "avax",
  solana: "solana", fantom: "ftm", cronos: "cronos", linea: "linea", zksync: "zksync", sui: "sui",
};

function money(v: unknown, digits = 2): number {
  const n = Number(v);
  return Number.isFinite(n) ? Number(n.toFixed(digits)) : 0;
}

type DexPair = {
  baseToken?: { address?: string; name?: string; symbol?: string };
  quoteToken?: { address?: string; symbol?: string };
  chainId?: string; dexId?: string; pairAddress?: string; url?: string;
  info?: { imageUrl?: string };
  priceUsd?: string;
  liquidity?: { usd?: number };
  volume?: { h24?: number };
  marketCap?: number; fdv?: number;
  priceChange?: { h24?: number };
  txns?: { h24?: { buys?: number; sells?: number } };
};

function choosePair(pairs: DexPair[], address: string): DexPair | null {
  const low = address.toLowerCase();
  let exact = pairs.filter((p) => (p.baseToken?.address ?? "").toLowerCase() === low);
  if (!exact.length) exact = pairs.filter((p) => (p.quoteToken?.address ?? "").toLowerCase() === low);
  if (!exact.length) return null;
  exact.sort((a, b) => {
    const score = (p: DexPair) =>
      (p.liquidity?.usd ?? 0) * 10 +
      (["USDC", "USDT", "USD", "DAI"].includes((p.quoteToken?.symbol ?? "").toUpperCase()) ? 1 : 0);
    return score(b) - score(a);
  });
  return exact[0] ?? null;
}

async function searchToken(address: string) {
  const r = await fetch(`${DEX}/latest/dex/search?q=${encodeURIComponent(address)}`, {
    signal: AbortSignal.timeout(12000),
  });
  if (!r.ok) throw new Error(`Live market service returned ${r.status}. Try again shortly.`);
  const json = (await r.json()) as { pairs?: DexPair[] };
  const pair = choosePair(json.pairs ?? [], address);
  if (!pair) throw new Error("Token not found on the indexed DEX markets.");
  let base = pair.baseToken ?? {};
  if ((base.address ?? "").toLowerCase() !== address.toLowerCase()) base = pair.quoteToken ?? base;
  return {
    address,
    name: base.name || "Unknown token",
    symbol: base.symbol || "TOKEN",
    chain_id: pair.chainId || "",
    dex_id: pair.dexId || "",
    pair_address: pair.pairAddress || "",
    pair_url: pair.url || "",
    image_url: pair.info?.imageUrl || "",
    price_usd: money(pair.priceUsd, 12),
    liquidity_usd: money(pair.liquidity?.usd, 2),
    volume_24h: money(pair.volume?.h24, 2),
    market_cap: money(pair.marketCap || pair.fdv, 2),
    fdv: money(pair.fdv, 2),
    market_cap_is_fdv: !pair.marketCap && !!pair.fdv,
    price_change_24h: money(pair.priceChange?.h24, 4),
    txns_24h: pair.txns?.h24 ?? {},
  };
}

export type TokenInfo = Awaited<ReturnType<typeof searchToken>>;

async function fxRate(currency: string): Promise<number> {
  if (currency === "USD") return 1;
  const r = await fetch(`${FX}/rate/usd/${currency.toLowerCase()}`, { signal: AbortSignal.timeout(10000) });
  if (!r.ok) throw new Error(`Currency service returned ${r.status}.`);
  const json = (await r.json()) as { rate: number };
  return json.rate;
}

function estimateSell(marketValue: number, liquidity: number): [number, number] {
  if (!liquidity || liquidity <= 0 || marketValue <= 0) return [marketValue, 0];
  const impact = Math.min(75, Math.max(0.5, 35 * Math.sqrt(marketValue / liquidity)));
  return [marketValue * (1 - impact / 100), impact];
}

export const getCurrencies = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const r = await fetch(`${FX}/currencies`, { signal: AbortSignal.timeout(10000) });
    if (!r.ok) throw new Error("fx down");
    return normalizeCurrencies(await r.json(), CURRENCY_FALLBACK);
  } catch {
    return CURRENCY_FALLBACK.map(([code, name, flag]) => ({ code, name, flag }));
  }
});

export const valuateToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { address: string; amount: string; currency: string }) => data)
  .handler(async ({ data, context }) => {
    const address = (data.address ?? "").trim();
    const currency = (data.currency ?? "NGN").trim().toUpperCase();
    if (!address) throw new Error("Paste a token contract address.");
    const amount = Number((data.amount ?? "").replace(/,/g, ""));
    if (!Number.isFinite(amount) || amount <= 0) throw new Error("Token amount must be greater than zero.");

    const token = await searchToken(address);
    const rate = await fxRate(currency);
    const marketValue = amount * token.price_usd;
    const local = marketValue * rate;
    const [sell, impact] = estimateSell(marketValue, token.liquidity_usd);
    const localSell = sell * rate;

    await context.supabase.from("valuations").insert({
      user_id: context.userId,
      token_address: address,
      token_name: token.name,
      token_symbol: token.symbol,
      chain_id: token.chain_id,
      image_url: token.image_url,
      amount: String(amount),
      price_usd: token.price_usd,
      market_value_usd: marketValue,
      local_value: local,
      currency,
      liquidity_usd: token.liquidity_usd,
      volume_24h: token.volume_24h,
      market_cap: token.market_cap,
      estimated_sell_value: sell,
      estimated_price_impact: impact,
    });

    return {
      ...token,
      amount: String(amount),
      market_value_usd: marketValue,
      local_value: local,
      local_sell_value: localSell,
      currency,
      fx_rate: rate,
      estimated_sell_value: sell,
      estimated_price_impact: impact,
      checked_at: new Date().toISOString(),
    };
  });

export type Valuation = Awaited<ReturnType<typeof valuateToken>> extends never ? never : {
  address: string; name: string; symbol: string; chain_id: string; dex_id: string;
  pair_address: string; pair_url: string; image_url: string; price_usd: number;
  liquidity_usd: number; volume_24h: number; market_cap: number; fdv: number;
  market_cap_is_fdv: boolean; price_change_24h: number; txns_24h: { buys?: number; sells?: number };
  amount: string; market_value_usd: number; local_value: number; local_sell_value: number;
  currency: string; fx_rate: number; estimated_sell_value: number; estimated_price_impact: number;
  checked_at: string;
};

export const getChart = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { address: string; range: string }) => data)
  .handler(async ({ data }) => {
    const address = (data.address ?? "").trim();
    if (!address) throw new Error("Missing token address");
    const token = await searchToken(address);
    const network = GECKO_NETWORKS[token.chain_id];
    if (!network || !token.pair_address) throw new Error("Historical chart is not available for this chain yet.");
    const configs: Record<string, [string, number, number]> = {
      "1d": ["hour", 1, 24], "7d": ["hour", 1, 168], "30d": ["hour", 4, 180],
      "1y": ["day", 1, 365], all: ["day", 1, 1000],
    };
    const cfg = configs[data.range] ?? configs["7d"]!;
    const [timeframe, aggregate, limit] = cfg;
    const r = await fetch(
      `${GECKO}/networks/${network}/pools/${token.pair_address}/ohlcv/${timeframe}?aggregate=${aggregate}&limit=${limit}&currency=usd`,
      { signal: AbortSignal.timeout(15000) },
    );
    if (!r.ok) throw new Error("Chart data is temporarily unavailable for this pool.");
    const json = (await r.json()) as { data?: { attributes?: { ohlcv_list?: number[][] } } };
    const arr = json.data?.attributes?.ohlcv_list ?? [];
    const points = arr
      .slice()
      .reverse()
      .map((x) => ({ time: (x[0] ?? 0) * 1000, open: x[1] ?? 0, high: x[2] ?? 0, low: x[3] ?? 0, close: x[4] ?? 0, volume: x[5] ?? 0 }));
    return { token, range: data.range, points };
  });

// --- DAI Miner (wallet-free chat flow) ---

function daiMode(): string {
  const requested = (process.env["DAI_MODE"] ?? "").trim().toLowerCase();
  if (["disabled", "disable", "off", "0", "false"].includes(requested)) return "disabled";
  return "chat";
}

async function runDaiChat(prompt: string): Promise<{ job_id: string; output: string }> {
  const minerUrl = (process.env["DAI_MINER_URL"] ?? "https://miner.iamai.kg").trim().replace(/\/$/, "");
  const r = await fetch(`${minerUrl}/chat/ask`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ message: prompt, wallet: "", requesterAddress: "", history: [] }),
    signal: AbortSignal.timeout(90000),
  });
  let body: unknown = null;
  try {
    body = await r.json();
  } catch {
    body = null;
  }
  if (!r.ok) {
    const msg =
      body && typeof body === "object" && "error" in body ? String((body as { error: unknown }).error) : `HTTP ${r.status}`;
    throw new Error(`Miner chat rejected the request: ${msg}`);
  }
  let text = "";
  if (body && typeof body === "object") {
    const rec = body as Record<string, unknown>;
    for (const k of ["reply", "response", "answer", "message", "text", "output", "content"]) {
      if (typeof rec[k] === "string" && (rec[k] as string).trim()) {
        text = rec[k] as string;
        break;
      }
    }
    if (!text) text = JSON.stringify(body).slice(0, 4000);
    const jobId = typeof rec["jobId"] === "string" ? (rec["jobId"] as string) : `chat-${Date.now()}`;
    return { job_id: jobId, output: text };
  }
  return { job_id: `chat-${Date.now()}`, output: String(body ?? "") };
}


export const getDaiStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const since = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
    const { count: mine } = await context.supabase
      .from("dai_jobs")
      .select("id", { count: "exact", head: true })
      .gte("created_at", since);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { count: total } = await supabaseAdmin
      .from("dai_jobs")
      .select("id", { count: "exact", head: true })
      .gte("created_at", since);
    return {
      configured: daiMode() !== "disabled",
      mode: daiMode(),
      remaining: Math.max(0, DAI_USER_DAILY_LIMIT - (mine ?? 0)),
      limit: DAI_USER_DAILY_LIMIT,
      global_remaining: Math.max(0, DAI_GLOBAL_DAILY_LIMIT - (total ?? 0)),
    };
  });

async function reserveDaiSlot(context: { userId: string; supabase: never }): Promise<{ slotId?: number; error?: string }> {
  const since = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { count: mine } = await supabaseAdmin
    .from("dai_jobs")
    .select("id", { count: "exact", head: true })
    .eq("user_id", context.userId)
    .gte("created_at", since);
  if ((mine ?? 0) >= DAI_USER_DAILY_LIMIT) {
    return { error: `Daily DAI analysis limit reached (${DAI_USER_DAILY_LIMIT} per 24h). Try again tomorrow.` };
  }
  const { count: total } = await supabaseAdmin
    .from("dai_jobs")
    .select("id", { count: "exact", head: true })
    .gte("created_at", since);
  if ((total ?? 0) >= DAI_GLOBAL_DAILY_LIMIT) {
    return { error: "The shared daily DAI budget for this demo has been used up. Please try again tomorrow." };
  }
  const { data, error } = await supabaseAdmin
    .from("dai_jobs")
    .insert({ user_id: context.userId })
    .select("id")
    .single();
  if (error || !data) return { error: "Could not reserve a DAI slot. Try again." };
  return { slotId: data.id };
}

async function releaseDaiSlot(slotId: number) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  await supabaseAdmin.from("dai_jobs").delete().eq("id", slotId);
}

function snapshotText(v: Valuation): string {
  return (
    `Token: ${v.name} (${v.symbol}); chain: ${v.chain_id || "unknown"}; contract: ${v.address}; ` +
    `amount: ${v.amount}; token price USD: ${v.price_usd}; quoted market value USD: ${money(v.market_value_usd, 8)}; ` +
    `estimated sell value USD: ${money(v.estimated_sell_value, 8)}; local value: ${money(v.local_value)} ${v.currency}; ` +
    `pool liquidity USD: ${money(v.liquidity_usd)}; market cap USD: ${money(v.market_cap)}. ` +
    `The sell value is a heuristic estimate, not a swap quote.`
  );
}

export const runDaiAnalysis = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { valuation: Valuation; question?: string | undefined }) => data)
  .handler(async ({ data, context }) => {
    if (daiMode() === "disabled") throw new Error("DAI integration is disabled.");
    const { slotId, error } = await reserveDaiSlot(context as never);
    if (error) throw new Error(error);
    try {
      const question = (data.question ?? "").trim();
      const prompt = question
        ? `You are analysing a crypto token valuation for a user of TrueWorth, a token value intelligence tool. Here is the valuation snapshot:\n\n${snapshotText(data.valuation)}\n\nThe user asks: ${question}\n\nAnswer concisely and plainly. Note that figures are estimates, not financial advice.`
        : `You are analysing a crypto token valuation for a user of TrueWorth, a token value intelligence tool. Analyse this valuation snapshot and give a short, plain-language risk assessment (liquidity, exit risk, anything notable):\n\n${snapshotText(data.valuation)}\n\nKeep it under 150 words. Note that figures are estimates, not financial advice.`;
      const result = await runDaiChat(prompt);
      return result;
    } catch (e) {
      await releaseDaiSlot(slotId!);
      throw e instanceof Error ? e : new Error("DAI request failed.");
    }
  });
