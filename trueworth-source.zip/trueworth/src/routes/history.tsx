import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/history")({
  head: () => ({
    meta: [
      { title: "Valuation history — TrueWorth" },
      { name: "description", content: "Your saved TrueWorth token valuations." },
      { property: "og:title", content: "Valuation history — TrueWorth" },
      { property: "og:description", content: "Your saved TrueWorth token valuations." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HistoryPage,
});

type Row = {
  id: number;
  token_name: string | null;
  token_symbol: string | null;
  chain_id: string | null;
  image_url: string | null;
  amount: string | null;
  local_value: number | null;
  currency: string | null;
  estimated_price_impact: number | null;
  checked_at: string;
};

function fmt(n: number | null): string {
  if (n == null || !Number.isFinite(n)) return "—";
  return n.toLocaleString(undefined, { maximumFractionDigits: 2 });
}

function HistoryPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [rows, setRows] = useState<Row[]>([]);
  const [fetching, setFetching] = useState(true);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("valuations")
      .select("id,token_name,token_symbol,chain_id,image_url,amount,local_value,currency,estimated_price_impact,checked_at")
      .order("id", { ascending: false })
      .limit(50)
      .then(({ data }) => {
        setRows((data as Row[]) ?? []);
        setFetching(false);
      });
  }, [user]);

  if (loading || !user) return null;

  return (
    <main className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="text-2xl font-bold tracking-tight">Valuation history</h1>
      <p className="mt-1 text-sm text-muted-foreground">Your 50 most recent valuations.</p>

      {fetching ? (
        <p className="mt-10 text-center text-sm text-muted-foreground animate-pulse-soft">Loading…</p>
      ) : rows.length === 0 ? (
        <div className="mt-10 rounded-2xl border border-border bg-card p-10 text-center">
          <p className="text-sm text-muted-foreground">No valuations yet.</p>
          <Link to="/" className="mt-4 inline-block rounded-lg bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90">
            Value a token
          </Link>
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          {rows.map((r) => (
            <div key={r.id} className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 animate-rise">
              {r.image_url ? (
                <img src={r.image_url} alt="" className="h-9 w-9 rounded-full border border-border" />
              ) : (
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary font-mono-num text-[10px] font-bold">
                  {(r.token_symbol ?? "?").slice(0, 3)}
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">
                  {r.token_name} <span className="font-mono-num text-xs text-muted-foreground">{r.token_symbol}</span>
                </p>
                <p className="text-xs text-muted-foreground">
                  {r.chain_id} · {new Date(r.checked_at).toLocaleString()}
                </p>
              </div>
              <div className="text-right">
                <p className="font-mono-num text-sm font-bold text-gain">
                  {fmt(r.local_value)} {r.currency}
                </p>
                <p className="font-mono-num text-[11px] text-muted-foreground">
                  impact ~{fmt(r.estimated_price_impact)}%
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
