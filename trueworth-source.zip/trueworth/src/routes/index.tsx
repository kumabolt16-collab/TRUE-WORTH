import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { useAuth } from "@/hooks/use-auth";
import {
  getCurrencies,
  getChart,
  getDaiStatus,
  runDaiAnalysis,
  valuateToken,
  type Valuation,
} from "@/lib/trueworth.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "TrueWorth — Token Value Intelligence" },
      {
        name: "description",
        content:
          "Paste a token contract address to identify the token, value your allocation in your currency, estimate exit risk, and run DAI analysis.",
      },
      { property: "og:title", content: "TrueWorth — Token Value Intelligence" },
      {
        property: "og:description",
        content:
          "Paste a token contract address to identify the token, value your allocation in your currency, estimate exit risk, and run DAI analysis.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function fmt(n: number, digits = 2): string {
  if (!Number.isFinite(n)) return "0";
  if (Math.abs(n) >= 1) return n.toLocaleString(undefined, { maximumFractionDigits: digits });
  return n.toLocaleString(undefined, { maximumSignificantDigits: 6 });
}

function PriceChart({ address }: { address: string }) {
  const getChartFn = useServerFn(getChart);
  const [range, setRange] = useState("7d");
  const [points, setPoints] = useState<Array<{ time: number; close: number | undefined }>>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    getChartFn({ data: { address, range } })
      .then((res) => {
        if (!cancelled) setPoints(res.points);
      })
      .catch((e) => {
        if (!cancelled) {
          setPoints([]);
          setError(e instanceof Error ? e.message : "Chart unavailable.");
        }
      })
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [address, range, getChartFn]);

  const closes = useMemo(
    () => points.map((p) => p.close).filter((c): c is number => typeof c === "number"),
    [points],
  );

  const path = useMemo(() => {
    if (closes.length < 2) return "";
    const w = 640;
    const h = 180;
    const min = Math.min(...closes);
    const max = Math.max(...closes);
    const span = max - min || 1;
    return closes
      .map((c, i) => {
        const x = (i / (closes.length - 1)) * w;
        const y = h - ((c - min) / span) * (h - 16) - 8;
        return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(" ");
  }, [closes]);

  const up = closes.length > 1 && (closes[closes.length - 1] ?? 0) >= (closes[0] ?? 0);

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-semibold">Price history</h3>
        <div className="flex gap-1">
          {["1d", "7d", "30d", "1y", "all"].map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors ${
                range === r ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary"
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>
      {loading ? (
        <div className="flex h-44 items-center justify-center text-sm text-muted-foreground">
          <span className="animate-pulse-soft">Loading chart…</span>
        </div>
      ) : error ? (
        <div className="flex h-44 items-center justify-center text-sm text-muted-foreground">{error}</div>
      ) : (
        <svg viewBox="0 0 640 180" className="h-44 w-full" preserveAspectRatio="none">
          <path d={path} fill="none" stroke={up ? "var(--color-gain)" : "var(--color-loss)"} strokeWidth="2" />
        </svg>
      )}
    </div>
  );
}

function DaiPanel({ valuation }: { valuation: Valuation }) {
  const runFn = useServerFn(runDaiAnalysis);
  const statusFn = useServerFn(getDaiStatus);
  const [status, setStatus] = useState<{ remaining: number; limit: number; configured: boolean } | null>(null);
  const [output, setOutput] = useState("");
  const [question, setQuestion] = useState("");
  const [busy, setBusy] = useState(false);

  const refreshStatus = () => statusFn().then(setStatus).catch(() => {});
  useEffect(() => {
    refreshStatus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function run(q?: string) {
    if (busy) return;
    setBusy(true);
    setOutput("");
    try {
      const res = await runFn({ data: { valuation, question: q } });
      setOutput(res.output);
      refreshStatus();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "DAI request failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-2xl border border-accent bg-card p-5">
      <div className="flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-sm font-semibold">
          <span className="h-2 w-2 rounded-full bg-glow animate-pulse-soft" />
          DAI analysis
        </h3>
        {status && (
          <span className="font-mono-num text-xs text-muted-foreground">
            {status.remaining}/{status.limit} runs left today
          </span>
        )}
      </div>
      <p className="mt-1 text-xs text-muted-foreground">
        Wallet-free DAI Miner chat — no wallet, key, or balance needed.
      </p>
      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <button
          onClick={() => run()}
          disabled={busy || (status ? status.remaining <= 0 : false)}
          className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground transition-colors hover:bg-accent/80 disabled:opacity-50"
        >
          {busy ? "Analysing…" : "Run DAI analysis"}
        </button>
        <div className="flex flex-1 gap-2">
          <input
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask DAI about this token…"
            className="flex-1 rounded-lg border border-input bg-secondary/60 px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/60"
            onKeyDown={(e) => {
              if (e.key === "Enter" && question.trim()) {
                run(question.trim());
                setQuestion("");
              }
            }}
          />
          <button
            onClick={() => {
              if (question.trim()) {
                run(question.trim());
                setQuestion("");
              }
            }}
            disabled={busy || !question.trim()}
            className="rounded-lg border border-border px-4 py-2 text-sm font-medium transition-colors hover:bg-secondary disabled:opacity-50"
          >
            Ask
          </button>
        </div>
      </div>
      {busy && <p className="mt-4 text-sm text-muted-foreground animate-pulse-soft">Waiting for the DAI Miner…</p>}
      {output && (
        <div className="mt-4 rounded-lg border border-border bg-secondary/40 p-4 text-sm leading-relaxed whitespace-pre-wrap animate-rise">
          {output}
        </div>
      )}
    </div>
  );
}

function Valuator() {
  const valuateFn = useServerFn(valuateToken);
  const currenciesFn = useServerFn(getCurrencies);
  const [address, setAddress] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState("NGN");
  const [currencies, setCurrencies] = useState<Array<{ code: string; name: string; flag: string }>>([]);
  const [result, setResult] = useState<Valuation | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    currenciesFn().then(setCurrencies).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      const res = await valuateFn({ data: { address, amount, currency } });
      setResult(res as Valuation);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Valuation failed.");
    } finally {
      setBusy(false);
    }
  }

  const inputCls =
    "w-full rounded-lg border border-input bg-secondary/60 px-3.5 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/60";

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <form onSubmit={submit} className="card-glow rounded-2xl border border-border bg-card p-6">
        <div className="grid gap-4 sm:grid-cols-[1fr_160px_130px]">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Token contract address</label>
            <input
              className={`${inputCls} font-mono-num`}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="0x… or Solana mint"
              required
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Amount</label>
            <input
              className={`${inputCls} font-mono-num`}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="1,000"
              required
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Currency</label>
            <select aria-label="Currency" className={inputCls} value={currency} onChange={(e) => setCurrency(e.target.value)}>
              {currencies.length === 0 && <option value="NGN">🇳🇬 NGN</option>}
              {currencies.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.flag} {c.code} — {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>
        <button
          type="submit"
          disabled={busy}
          className="mt-5 w-full rounded-lg bg-primary py-3 text-sm font-bold tracking-wide text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50"
        >
          {busy ? "VALUING…" : "VALUE MY TOKENS"}
        </button>
      </form>

      {result && (
        <div className="mt-6 space-y-6 animate-rise">
          <div className="card-glow rounded-2xl border border-border bg-card p-6">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                {result.image_url ? (
                  <img src={result.image_url} alt="" className="h-11 w-11 rounded-full border border-border" />
                ) : (
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-secondary font-mono-num text-xs font-bold">
                    {result.symbol.slice(0, 3)}
                  </div>
                )}
                <div>
                  <h2 className="text-lg font-bold leading-tight">{result.name}</h2>
                  <p className="font-mono-num text-xs text-muted-foreground">
                    {result.symbol} · {result.chain_id}
                  </p>
                </div>
              </div>
              <span
                className={`rounded-md px-2 py-1 font-mono-num text-xs font-semibold ${
                  result.price_change_24h >= 0 ? "bg-gain/15 text-gain" : "bg-loss/15 text-loss"
                }`}
              >
                {result.price_change_24h >= 0 ? "+" : ""}
                {fmt(result.price_change_24h)}% 24h
              </span>
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl bg-secondary/50 p-4">
                <p className="text-xs text-muted-foreground">Market value</p>
                <p className="mt-1 font-mono-num text-2xl font-bold text-gain text-glow">
                  {fmt(result.local_value)} {result.currency}
                </p>
                <p className="mt-0.5 font-mono-num text-xs text-muted-foreground">${fmt(result.market_value_usd)} USD</p>
              </div>
              <div className="rounded-xl bg-secondary/50 p-4">
                <p className="text-xs text-muted-foreground">Estimated sell value</p>
                <p className="mt-1 font-mono-num text-2xl font-bold text-warn">
                  {fmt(result.local_sell_value)} {result.currency}
                </p>
                <p className="mt-0.5 font-mono-num text-xs text-muted-foreground">
                  ~{fmt(result.estimated_price_impact)}% price impact (heuristic)
                </p>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                ["Price", `$${fmt(result.price_usd, 8)}`],
                ["Liquidity", `$${fmt(result.liquidity_usd)}`],
                ["24h volume", `$${fmt(result.volume_24h)}`],
                [result.market_cap_is_fdv ? "FDV" : "Market cap", `$${fmt(result.market_cap)}`],
              ].map(([label, value]) => (
                <div key={label} className="rounded-lg border border-border p-3">
                  <p className="text-[11px] text-muted-foreground">{label}</p>
                  <p className="mt-0.5 font-mono-num text-sm font-semibold">{value}</p>
                </div>
              ))}
            </div>
            <p className="mt-4 text-[11px] leading-relaxed text-muted-foreground">
              Sell value and price impact are heuristic estimates, not executable swap quotes or financial advice.
              Checked {new Date(result.checked_at).toLocaleString()}.
            </p>
          </div>

          <PriceChart address={result.address} />
          <DaiPanel valuation={result} />
        </div>
      )}
    </div>
  );
}

function Landing() {
  return (
    <main className="surface-grid">
      <section className="mx-auto flex max-w-4xl flex-col items-center px-4 py-24 text-center">
        <span className="rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
          Token value intelligence
        </span>
        <h1 className="mt-6 text-4xl font-bold tracking-tight sm:text-6xl">
          What are your tokens <span className="text-primary text-glow">really worth?</span>
        </h1>
        <p className="mt-5 max-w-xl text-base leading-relaxed text-muted-foreground">
          Paste any token contract address. TrueWorth identifies the token, values your allocation in your own
          currency, estimates how much you could actually sell it for, and runs DAI-powered risk analysis.
        </p>
        <Link
          to="/auth"
          className="mt-8 rounded-lg bg-primary px-8 py-3 text-sm font-bold text-primary-foreground transition-colors hover:bg-primary/90"
        >
          Get started free
        </Link>
        <div className="mt-16 grid gap-4 text-left sm:grid-cols-3">
          {[
            ["Identify", "Any contract address, any major chain — name, symbol, price, liquidity, volume."],
            ["Value", "Your allocation converted into 60+ currencies with live exchange rates."],
            ["Analyse", "Exit-risk heuristics plus wallet-free DAI Miner analysis on every valuation."],
          ].map(([title, body]) => (
            <div key={title} className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-semibold text-primary">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{body}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}

function Index() {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="flex min-h-[calc(100vh-3.5rem)] items-center justify-center">
        <span className="animate-pulse-soft text-sm text-muted-foreground">Loading…</span>
      </div>
    );
  }
  return user ? <Valuator /> : <Landing />;
}
