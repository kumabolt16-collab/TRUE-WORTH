import { describe, expect, it } from "vitest";
import { normalizeCurrencies } from "@/lib/currencies";

const fallback: Array<[string, string, string]> = [
  ["NGN", "Nigerian Naira", "🇳🇬"],
  ["USD", "US Dollar", "🇺🇸"],
];

describe("Currency selector data", () => {
  it("uses ISO codes and currency names rather than array indexes or numeric codes", () => {
    const result = normalizeCurrencies([
      { iso_code: "NGN", iso_numeric: "566", name: "Nigerian Naira" },
      { iso_code: "USD", iso_numeric: "840", name: "US Dollar" },
    ], fallback);
    expect(result).toEqual([
      { code: "USD", name: "US Dollar", flag: "🇺🇸" },
      { code: "NGN", name: "Nigerian Naira", flag: "🇳🇬" },
    ]);
  });

  it("ignores invalid records and deduplicates codes", () => {
    expect(normalizeCurrencies([
      null, { iso_code: "566" }, { iso_code: "NGN" }, { iso_code: "NGN", name: "Nigerian Naira" },
    ], fallback)).toEqual([{ code: "NGN", name: "Nigerian Naira", flag: "🇳🇬" }]);
  });

  it("rejects malformed or empty responses so the caller can use the fallback", () => {
    for (const value of [null, {}, [], [{ iso_code: "0" }]]) {
      expect(() => normalizeCurrencies(value, fallback)).toThrow();
    }
  });
});